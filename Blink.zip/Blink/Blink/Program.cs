﻿using System;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.IO;
using Microsoft.SPOT;
using Microsoft.SPOT.Hardware;
using Microsoft.SPOT.Net.NetworkInformation;
using SecretLabs.NETMF.Hardware;
using SecretLabs.NETMF.Hardware.Netduino;
using System.Text;

namespace SmartPlant
{
    public class Program
    {
        static Socket mySocket = null;

        /*
        private const string HOST = "[IOT_HUB_NAME].azure-devices.net";
        private const int PORT = 5671;
        private const string DEVICE_ID = "[DEVICE_ID]";
        private const string DEVICE_KEY = "[DEVICE_KEY]";
*/

        private const string HOST = "IoTApps.azure-devices.net";
        private const int PORT = 5671;
        private const string DEVICE_ID = "smartplant1";
        private const string DEVICE_KEY = "+KPMW6B/55LF/G7ti7ffr5I5IysYueyRVigkcWzA3dw=";

        public static void Main()
        {
            Thread.Sleep(5000); // sleep for 2500ms
            while (IPAddress.GetDefaultLocalAddress() == IPAddress.Any)
            {
                Debug.Print("Sleep while obtaining an IP");
                Thread.Sleep(10);
            };

            Debug.Print("Start");

            int returnCode = 0;


            // Get broker's IP address.
            //IPHostEntry hostEntry = Dns.GetHostEntry("test.mosquitto.org");
            Debug.Print("Ready");

            IPHostEntry hostEntry = Dns.GetHostEntry(HOST);
            // Create socket and connect to the broker's IP address and port
            mySocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                Debug.Print("Connect");
                mySocket.Connect(new IPEndPoint(hostEntry.AddressList[0], PORT));
                Debug.Print("Connected");
            }
            catch (SocketException SE)
            {
                Debug.Print("Connection Error: " + SE.ErrorCode);
                return;
            }

            string userName = HOST + "/" + DEVICE_ID + "/api-version=2016-11-14";
            //string resourceUri = HOST + "/devices/" + DEVICE_ID;
            string eventUri = "/devices/" + DEVICE_ID + "/messages/events";
            Debug.Print("SAS");
            string sasToken = GetSharedAccessSignature(null, DEVICE_KEY, userName, new TimeSpan(1, 0, 0));
            Debug.Print("Got Token:" + sasToken);

            // Send the connect message
            // You can use UTF8 in the clientid, username and password - be careful, this can be a pain
            //returnCode = NetduinoMQTT.ConnectMQTT(mySocket, "tester\u00A5", 2000, true, "roger\u00A5", "password\u00A5");
            returnCode = NetduinoMQTT.ConnectMQTT(mySocket, DEVICE_ID, 20, true, userName, sasToken);
            if (returnCode != 0)
            {
                Debug.Print("Connection Error: " + returnCode.ToString());
                return;
            }

            NetduinoMQTT.PingMQTT(mySocket);

            // Publish a message
            NetduinoMQTT.PublishMQTT(mySocket, eventUri, "Testing from NetduinoMQTT");

            Debug.Print("Success done");
        }

        private static readonly long UtcReference = (new DateTime(1970, 1, 1, 0, 0, 0, 0)).Ticks;
        public const long TicksPerMillisecond = 10000;
        public const long TicksPerSecond = TicksPerMillisecond * 1000;   // 10,000,000
        private const double SecondsPerTick = 1.0 / TicksPerSecond;         // 0.0001

        static string GetSharedAccessSignature(string keyName, string sharedAccessKey, string resource, TimeSpan tokenTimeToLive)
        {
            // http://msdn.microsoft.com/en-us/library/azure/dn170477.aspx
            // the canonical Uri scheme is http because the token is not amqp specific
            // signature is computed from joined encoded request Uri string and expiry string

#if NETMF
            // needed in .Net Micro Framework to use standard RFC4648 Base64 encoding alphabet
            System.Convert.UseRFC4648Encoding = true;
#endif
            TimeSpan timespan = DateTime.UtcNow - new DateTime(UtcReference, DateTimeKind.Utc) + tokenTimeToLive;

            long Totalseconds = (long)(timespan.Ticks * SecondsPerTick);
            string expiry = Totalseconds.ToString();

            Debug.Print("Expiry: " + Totalseconds.ToString());

            Debug.Print("Token:" + tokenTimeToLive.Ticks.ToString());
            string encodedUri = HttpUtility.UrlEncode(resource);

            byte[] hmac = SHA.computeHMAC_SHA256(Convert.FromBase64String(sharedAccessKey), Encoding.UTF8.GetBytes(encodedUri + "\n" + expiry));
            string sig = Convert.ToBase64String(hmac);

            if (keyName != null)
            {
                return "SharedAccessSignature sr=" + encodedUri + "&sig=" + HttpUtility.UrlEncode(sig) + "&se=" + HttpUtility.UrlEncode(expiry) + "&skn=" + HttpUtility.UrlEncode(keyName);
            }
            else
            {
                return
                    "SharedAccessSignature sr=" + encodedUri + "&sig=" + HttpUtility.UrlEncode(sig) + "&se=" + HttpUtility.UrlEncode(expiry);
            }
        }

    }
}